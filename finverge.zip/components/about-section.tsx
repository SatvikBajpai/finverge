"use client"

import Image from "next/image"
import { motion } from "framer-motion"

export function AboutSection() {
  return (
    <section id="about-section" className="w-full py-16 md:py-24 bg-white">
      <div className="container mx-auto px-2 sm:px-3 md:px-4">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
          >
            <h2 className="text-3xl md:text-4xl font-bold tracking-tighter text-[#1B365D]">About FinVerge</h2>
            <p className="text-gray-600 text-lg">
              At FinVerge Advisors, we specialize in empowering startups and SMEs to transform their finance functions
              into strategic growth drivers. Our tailored solutions are designed to meet the unique needs of
              forward-thinking businesses.
            </p>
            <p className="text-gray-600 text-lg">
              We focus on enhancing agility, providing actionable insights, delivering real-time decision support, and
              establishing accountability through careful financial planning and monitoring.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="relative h-[200px] rounded-lg overflow-hidden shadow-md">
              <Image
                src="https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&auto=format&fit=crop&q=80"
                alt="Financial analytics dashboard on computer screen"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative h-[200px] rounded-lg overflow-hidden shadow-md">
              <Image
                src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80"
                alt="Financial documents and calculator"
                fill
                className="object-cover"
              />
            </div>
            <div className="relative h-[200px] rounded-lg overflow-hidden shadow-md col-span-2">
              <Image
                src="https://images.unsplash.com/photo-1591696205602-2f950c417cb9?w=800&auto=format&fit=crop&q=80"
                alt="Modern office workspace with financial charts"
                fill
                className="object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

